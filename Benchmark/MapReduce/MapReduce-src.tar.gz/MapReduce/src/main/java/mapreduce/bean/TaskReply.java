package mapreduce.bean;

public interface TaskReply {
}
