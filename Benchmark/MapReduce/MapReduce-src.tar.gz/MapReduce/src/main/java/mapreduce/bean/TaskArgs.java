package mapreduce.bean;

public interface TaskArgs {
}
