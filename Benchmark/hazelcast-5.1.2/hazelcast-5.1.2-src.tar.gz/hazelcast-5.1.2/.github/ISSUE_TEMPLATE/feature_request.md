---
name: "Feature request"
about: Suggest an idea for this project
labels: 'Type: Enhancement'		
---

<!--
Thank you for suggesting an idea to make Hazelcast better.

Please fill in as much of the template below as you're able.
-->

**Please describe the problem you are trying to solve**
...

**Please describe the desired behavior**
...

**Describe alternatives you've considered**
...
