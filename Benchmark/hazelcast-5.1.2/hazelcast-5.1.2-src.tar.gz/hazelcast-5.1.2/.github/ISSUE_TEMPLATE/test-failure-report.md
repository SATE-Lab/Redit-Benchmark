---
name: test-failure report
about: Template for test failures in testsuite
title: INSERT_FULL_TEST_NAME_HERE
labels: ['Type: Test-Failure']
assignees: ''

---

_INSERT_BRANCH_NAME_HERE_ (commit INSERT_COMMIT_ID_HERE)

Failed on INSERT_PLATFORM_INFORMATION_HERE: INSERT_LINK_TO_JENKINS_TEST_RESULT_HERE

<details><summary>Stacktrace:</summary>

```
INSERT_STACKTRACE_HERE
```

</details>

<details><summary>Standard output:</summary>

```
INSERT_INTERESTING_PART_OF_STANDARD_OUTPUT_HERE
```

</details>
